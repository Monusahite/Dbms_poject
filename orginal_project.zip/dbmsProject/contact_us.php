<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		p{
			font-weight:lighter;
		     text-align: center;
		     font-size: .8rem;
		}
		.JTH{
			font-weight: bold;
			font-size: 1.5rem;

		}
		.connect{
			background: #333;
			color: white;
			font-size: 1rem;
			width: 70%;
			margin-top: 5rem;
			padding:1rem;
			margin-left: 15%;
		}
		a{
			color: yellow;
		}
	</style>
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>
<body>
    <div class ="contact">
    	
          <h1 style="text-align: center;color:#333;font-style:monospace;font-size: 3rem;">Contact Us</h1>
          <div>
          	<p > <span class="JTH">JTH</span> is Platform to get (Tent-House, Catering, DJ-Sound, Photographer, Decorators) for Marriage, BirthDay-Celebrations, and Other type of Events. It's helpful for small towns/villages. </p>
            <p>JTH is an online platform just like 'JustDial' or 'Dukaan.com'</p>
          </div>

          <div class="connect">
          	  <p><span>Mail us:</span> rrajput@iitg.ac.in  ,  msahite@iitg.ac.in</i></p>
          	  <p><span>Linkdin:</span>  <a href="https://www.linkedin.com/in/ram-rajput-b55310199/">Ram Rajput</a> ,  <a href="https://www.linkedin.com/in/monusahite/">Monu Sahite</a></p>
          </div>
 
    </div>
</body>
</html>