<?php session_start();
// session_destroy(); 
// print_r($_SESSION['cart']);
require_once('./component.php');
require_once('./dbcreate.php');
include("header.php");



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            .col-lg-3{
              margin:2rem;
             }
             .card-body{
              display:flex;
              justify-content:space-around;
             }
             input[type="number"]{
              width:4rem;
              padding:5px;
             }
            .common{
                display:flex;
                justify-content:space-around;
                flex-wrap:wrap;
                padding: 1% 10%;
            }
            .body{
             background-color:#FDF5DF;

            }
        </style>
</head>
<body class="body">
    <hr>
    <h1 class="text-center">Stages</h1>
    <hr>
    <div class="common">
           <?php
             component('..\simages\simages\stages1.jpg','stage1');
             component('..\simages\simages\stages2.jpg','stage2');
             component('..\simages\simages\stages3.jpg','stage3');
             component('..\simages\simages\stages4.jpg','stage4');
             component('..\simages\simages\stages5.jpg','stage5');
             component('..\simages\simages\stages6.jpg','stage6');
           ?>
    </div>
    <hr>
    <h1 class="text-center">Curtains</h1>
    <hr>
    <div class="common">
           <?php
             component('..\simages\simages\curtain1.jpg','curtain1');
             component('..\simages\simages\curtain2.jpg','curtain2');
             component('..\simages\simages\curtain3.jpg','curtain3');
             component('..\simages\simages\curtain4.jpg','curtain4');
            //  component('..\simages\simages\curtain5.jpg','curtain5');
             component('..\simages\simages\curtain6.jpg','curtain6');
           ?>
    </div>

</body>
</html>