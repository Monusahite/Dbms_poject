<?php

require_once('./dbcreate.php');
  
$database = new CreateDb('DBMS','shop');
  if(isset($_POST['submit']) && isset($_FILES['my_image'])){
    echo "<pre>";
    print_r($_FILES['my_image']);
    echo "<pre>";
    

    $img_name = $_FILES['my_image']['name'];
    $img_size = $_FILES['my_image']['size'];
    $tmp_name = $_FILES['my_image']['tmp_name'];
    $error = $_FILES['my_image']['error'];
    $size = $_FILES['my_image']['size'];
   
    $img_ex = pathinfo($img_name,PATHINFO_EXTENSION);
    $img_ex_lc = strtolower($img_ex);
    $allowed_exs = array("jpg","jpeg","png");

   echo "$img_ex";

  }   
?>