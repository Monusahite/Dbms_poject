<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Responsive Event Organizer Website Design Tutorial</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="#" class="logo"><span>J</span>TH</a>
        <a href="seller/slogin.html" ><button class="buttonnav" type="button">Click Me!</button>
          </a>
        <nav class="navbar">
            <a href="#home">Tent-House</a>
            <a href="#service">Catering</a>
            <a href="#about">DJ-Sound</a>
            <a href="#gallery">Photography</a>
            <a href="#review">Decoration</a>
        </nav>

        <div id="menu-bars" class="fas fa-bars"></div>

    </header>
   

</body>

</html>
