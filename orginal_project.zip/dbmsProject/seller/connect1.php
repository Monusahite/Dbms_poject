<?php
$servername = "localhost";
$username = "root";
$password = "root@123";
$dbname = "DBMS";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
