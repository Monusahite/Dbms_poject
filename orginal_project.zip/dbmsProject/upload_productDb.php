
<?php
$username ="root";
 $password ="root@123";
 $server ="localhost";
 $db ="DBMS";

$conn = new mysqli($server, $username, $password, $db);

$dir    = '/var/www/html/dbmsProject/simages';
$files1 = scandir($dir);
 $sql = " CREATE TABLE IF NOT EXISTS Available_Products
                            (Pid INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                             Pname VARCHAR(255) ,
                             imagePath varchar(255)                    
                            )";    
 mysqli_query($conn, $sql);
for ($x = 2; $x < count($files1); $x++) {

     $temp = basename($files1[$x],'.jpg');
     $path ="simages/".$files1[$x];
     $sql1 = "INSERT INTO DBMS.Available_Products(Pname,imagePath) VALUES('$temp','$path')";
     if (mysqli_query($conn, $sql1)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
}
 
	
} 
?>
